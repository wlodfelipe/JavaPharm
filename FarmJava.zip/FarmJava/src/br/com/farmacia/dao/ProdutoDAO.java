/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.farmacia.dao;

import br.com.farmacia.jdbc.ConexaoBanco;
import br.com.farmacia.model.Produto;
import java.sql.Connection;  // Use java.sql.Connection
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;


/**
 *
 * @author felipewlod
 */
public class ProdutoDAO {
    private Connection conexao;

    public ProdutoDAO() {
        this.conexao = new ConexaoBanco().conectardb();
    }
    
    public void SalvarProduto(Produto obj){
        try {
            //Cria a Query
            String sql = "INSERT INTO `produto`"
                    +"(`nome_produto`, "
                    + "`ID_classe_produto`, `valor_produto`, "
                    + "`vencimento_produto`, `receita_obrigatoria`,"
                    + "`qtd_estoque`) "
                    
                    + "VALUES (?," //nome
                    + " (SELECT ID_classe_produto FROM classe_produto WHERE nome_classe_produto = ?)," //id classe
                    + " ?," //valor
                    + " ?," // vencimento
                    + " ?," // receita
                    + " ?)"; //quantidade

            // Inicia e prepara a conexão com o BD
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getClasse());
            stmt.setFloat(3, obj.getValor());
            stmt.setString(4, obj.getDataVencimento());
            stmt.setBoolean(5, obj.getReceitaObrigatoria());
            stmt.setInt(6, obj.getQuantidade());
            
            // Executa a Query
            stmt.execute();
            
            // Fecha a conexão
            stmt.close();
            
            // Aviso que deu certo
            JOptionPane.showMessageDialog(null, "Produto salvo!");
                
        }catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro ao salvar Produto." + erro);
                }
    }
    
    public void EditarProduto(Produto obj){
        try {
            //Cria a Query
            String sql = "UPDATE `produto` SET "
                        + "`nome_produto` = ?, "
                        + "`ID_classe_produto` = (SELECT ID_classe_produto FROM classe_produto WHERE nome_classe_produto = ?), "
                        + "`valor_produto` = ?, "
                        + "`vencimento_produto` = ?, "
                        + "`receita_obrigatoria` = ?, "
                        + "`qtd_estoque` = ? "
                        + "WHERE `ID_produto` = ?;";

            // Inicia e prepara a conexão com o BD
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getClasse());
            stmt.setFloat(3, obj.getValor());
            stmt.setString(4, obj.getDataVencimento());
            stmt.setBoolean(5, obj.getReceitaObrigatoria());
            stmt.setInt(6, obj.getQuantidade());
            stmt.setInt(7, obj.getId());
            
            // Executa a Query
            stmt.execute();
            
            // Fecha a conexão
            stmt.close();
            
            // Aviso que deu certo
            JOptionPane.showMessageDialog(null, "Produto editado com sucesso!");
                
        }catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro ao editar Produto." + erro);
                }
    }
    
    public Produto BuscarProduto(String nome){
        try {
            String sql = "SELECT p.ID_produto,"
                    + " p.nome_produto, c.nome_classe_produto,"
                    + " p.qtd_estoque, p.receita_obrigatoria,"
                    + " p.vencimento_produto,"
                    + " p.valor_produto"                    
                    + " FROM produto AS p"
                    + " LEFT JOIN classe_produto AS c"
                    + " ON (c.ID_classe_produto = p.ID_classe_produto)"
                    + " WHERE nome_produto LIKE ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            Produto obj = new Produto();
            
            if (rs.next()){
                obj.setId(rs.getInt("p.ID_produto"));                
                obj.setNome(rs.getString("p.nome_produto"));
                obj.setClasse(rs.getString("c.nome_classe_produto"));
                obj.setQuantidade(rs.getInt("p.qtd_estoque"));                
                obj.setReceitaObrigatoria(rs.getBoolean("p.receita_obrigatoria"));                
                obj.setValor(rs.getFloat("p.valor_produto")); 
                obj.setDataVencimento(rs.getString("p.vencimento_produto"));
                
            }
            return obj;
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao mostrar tabela" + e);
        }
        return null;
    }
    public ArrayList<Produto> Listar(){
        ArrayList<Produto> lista = new ArrayList<>();
        try {                    
            String sql ="SELECT p.ID_produto,"
                    + " p.nome_produto, c.nome_classe_produto,"
                    + " p.qtd_estoque, p.receita_obrigatoria,"
                    + " p.valor_produto"                    
                    + " FROM produto AS p"
                    + " LEFT JOIN classe_produto AS c"
                    + " ON (c.ID_classe_produto = p.ID_classe_produto)";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while (rs.next()){
                Produto obj = new Produto();
                obj.setId(rs.getInt("p.ID_produto"));                
                obj.setNome(rs.getString("p.nome_produto"));
                obj.setClasse(rs.getString("c.nome_classe_produto"));
                obj.setQuantidade(rs.getInt("p.qtd_estoque"));                
                obj.setReceitaObrigatoria(rs.getBoolean("p.receita_obrigatoria"));                
                obj.setValor(rs.getFloat("p.valor_produto"));                

                lista.add(obj);
            }
            return lista;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "erro ao listar"+e);
        }
        return null;
    }
    
    public ArrayList<Produto> Filtrar(String nome){
        ArrayList<Produto> lista = new ArrayList<>();
        try {
            String sql = "SELECT c.ID_cliente,"
                    + " c.nome_cliente,"
                    + " c.email_cliente,"
                    + " c.cpf_cnpj_cliente,"
                    + " g.nome_genero,"
                    + " c.nacionalidade_cliente"
                    + " FROM cliente_cadastro AS c"
                    + " LEFT JOIN genero AS g"
                    + " ON (g.id_genero = c.ID_genero)"
                    + " WHERE c.nome_cliente LIKE ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()){
                Produto obj = new Produto();
                obj.setId(rs.getInt("c.ID_cliente"));
                obj.setNome(rs.getString("c.nome_cliente"));
               
                lista.add(obj);
            }
            return lista;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "erro ao listar"+e);
        }
        return null;
    }
    
    public void Excluir(Produto obj){
        try {
            String sql = "DELETE FROM produto WHERE ID_produto = ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setInt(1, obj.getId());
            
            stmt.execute();
            stmt.close();
            
            JOptionPane.showMessageDialog(null, "Excluído com sucesso");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao excluir"+e);

        }

    }
}


