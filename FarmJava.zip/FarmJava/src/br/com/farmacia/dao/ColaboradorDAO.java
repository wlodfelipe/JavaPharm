/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.farmacia.dao;

import br.com.farmacia.jdbc.ConexaoBanco;
import br.com.farmacia.model.Cliente;
import br.com.farmacia.model.Colaborador;
import br.com.farmacia.view.AreaTrabalho;
import java.sql.Connection;  // Use java.sql.Connection
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


/**
 *
 * @author felipewlod
 */
public class ColaboradorDAO {
    private Connection conexao;

    public ColaboradorDAO() {
        this.conexao = new ConexaoBanco().conectardb();
    }
    
    public static String hashSenha(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void SalvarColaborador(Colaborador obj){
        try {
            //Cria a Query
            String sql = "INSERT INTO `admin` "
                    + "(`senha_admin`, `nomeFuncionario`,"
                    + " `emailFuncionario`, `cargoFuncionario`,"
                    + " `nivelAcessoFuncionario`)"
                    + " VALUES"
                    + " (?, ?, ?, ?, ?)";
            // Inicia e prepara a conexão com o BD
            String plainSenha = obj.getSenha();
            String email = obj.getEmail();
            String saltedSenha = plainSenha.concat(email);
            String hashedSenha = hashSenha(saltedSenha);
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, hashedSenha);
            stmt.setString(2, obj.getNome());
            stmt.setString(3, obj.getEmail());
            stmt.setString(4, obj.getCargo());
            stmt.setString(5, obj.getNivelAcesso());
            
            // Executa a Query
            stmt.execute();
            
            // Fecha a conexão
            stmt.close();
            
            // Aviso que deu certo
            JOptionPane.showMessageDialog(null, "Colaborador salvo!");
                
        }catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro ao salvar colaborador." + erro);
                }
    }
    
    public void EditarColaborador(Colaborador obj){
        try {
            //Cria a Query
            String sql = "UPDATE `admin` SET"
                    //+ " `senha_admin` = ?,"
                    + " `nomeFuncionario` = ?,"
                    + " `emailFuncionario` = ?,"
                    + " `cargoFuncionario` = ?,"
                    + " `nivelAcessoFuncionario` = ?"
                    + " WHERE `ID_admin` = ?";

            // Inicia e prepara a conexão com o BD
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            //stmt.setString(1, obj.getSenha());
            stmt.setString(1, obj.getNome());
            stmt.setString(2, obj.getEmail());
            stmt.setString(3, obj.getCargo());
            stmt.setString(4, obj.getNivelAcesso());
            stmt.setInt(5, obj.getId());
            
            // Executa a Query
            stmt.execute();
            
            // Fecha a conexão
            stmt.close();
            
            // Aviso que deu certo
            JOptionPane.showMessageDialog(null, "Colaborador editado com sucesso!");
                
        }catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro ao editar colaborador." + erro);
                }
    }
    
    public Cliente BuscarColaborador(String nome){
        try {
            String sql = "SELECT a.ID_admin, a.nomeFuncionario, a.emailFuncionario, a.cargoFuncionario, a.nivelAcessoFuncionario"
                    + " FROM admin AS a"
                    + " WHERE nomeFuncionario LIKE ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            Colaborador obj = new Colaborador();
            
            if (rs.next()){
                obj.setId(rs.getInt("a.ID_admin"));
                obj.setNome(rs.getString("a.nomeFuncionario"));
                obj.setEmail(rs.getString("a.emailFuncionario"));
                obj.setCargo(rs.getString("a.cargoFuncionario"));
                obj.setNivelAcesso(rs.getString("a.nivelAcessoFuncionario"));
            }
            return obj;
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao mostrar tabela" + e);
        }
        return null;
    }
    public ArrayList<Colaborador> Listar(){
        ArrayList<Colaborador> lista = new ArrayList<>();
        try {
            String sql = "SELECT a.ID_admin, a.nomeFuncionario, a.emailFuncionario, a.cargoFuncionario, a.nivelAcessoFuncionario"
                    + " FROM admin AS a";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while (rs.next()){
                Colaborador obj = new Colaborador();
                obj.setId(rs.getInt("a.ID_admin"));
                obj.setNome(rs.getString("a.nomeFuncionario"));
                obj.setEmail(rs.getString("a.emailFuncionario"));
                obj.setCargo(rs.getString("a.cargoFuncionario"));
                obj.setNivelAcesso(rs.getString("a.nivelAcessoFuncionario"));
                lista.add(obj);
            }
            return lista;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "erro ao listar colaboradores "+e);
        }
        return null;
    }
    
    public ArrayList<Colaborador> Filtrar(String nome){
        ArrayList<Colaborador> lista = new ArrayList<>();
        try {
            String sql = "SELECT a.ID_admin, a.nomeFuncionario, a.emailFuncionario, a.cargoFuncionario, a.nivelAcessoFuncionario"
                    + " FROM admin AS a "
                    + "WHERE nomeFuncionario LIKE ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()){
                Colaborador obj = new Colaborador();
                obj.setId(rs.getInt("a.ID_admin"));
                obj.setNome(rs.getString("a.nomeFuncionario"));
                obj.setEmail(rs.getString("a.emailFuncionario"));
                obj.setCargo(rs.getString("a.cargoFuncionario"));
                obj.setNivelAcesso(rs.getString("a.nivelAcessoFuncionario"));
                lista.add(obj);
            }
            return lista;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "erro ao listar"+e);
        }
        return null;
    }
    
    public void Excluir(Colaborador obj){
        try {
            String sql = "DELETE FROM admin WHERE ID_admin = ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setInt(1, obj.getId());
            
            stmt.execute();
            stmt.close();
            
            JOptionPane.showMessageDialog(null, "Excluído com sucesso");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao excluir"+e);

        }

    }
    
    public int efetuarLogin(String email, String senha){
        try {
            //Cria a Query
            String sql = "SELECT senha_admin FROM admin WHERE emailFuncionario = ?";

            // Inicia e prepara a conexão com o BD            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, email);

            // Executa a Query
            ResultSet rs = stmt.executeQuery();

            if (rs.next()){
                String senhaBanco = rs.getString("senha_admin");
                String saltedSenha = senha.concat(email);
                String hashedSenha = hashSenha(saltedSenha);

                if (hashedSenha.equals(senhaBanco)){
                    new AreaTrabalho().setVisible(true);
                    JOptionPane.showMessageDialog(null, "Bem vindo!");
                } else {
                    JOptionPane.showMessageDialog(null, "Senha incorreta.");
                    return -1;
                }
            } else {
                JOptionPane.showMessageDialog(null, "Usuário não encontrado.");
            }

            stmt.close();
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Erro ao Logar: " + erro);
        }
        return 0;
    }
}


