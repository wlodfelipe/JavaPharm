/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package br.com.farmacia.jdbc;

/**
 *
 * @author felipewlod
 */

import java.awt.HeadlessException;
import javax.swing.JOptionPane;

public class ConnectarDB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            new ConexaoBanco().conectardb();
            JOptionPane.showMessageDialog(null, "Conectado ao DB");
        }
        catch (HeadlessException erro) {
            JOptionPane.showMessageDialog(null, "Falha ao conectar ao DB");
        }
        }
    
}
