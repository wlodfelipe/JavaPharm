/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.farmacia.dao;

import br.com.farmacia.jdbc.ConexaoBanco;
import br.com.farmacia.model.Cliente;
import java.sql.Connection;  // Use java.sql.Connection
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.ArrayList;


/**
 *
 * @author felipewlod
 */
public class ClienteDAO {
    private Connection conexao;

    public ClienteDAO() {
        this.conexao = new ConexaoBanco().conectardb();
    }
    
    public void SalvarCliente(Cliente obj){
        try {
            //Cria a Query
            String sql = "INSERT INTO `cliente_cadastro`"
                    +"(`cpf_cnpj_cliente`,"
                    + "`nome_cliente`, `email_cliente`, "
                    + "`ID_genero`, `quantidade_filhos_cliente`,"
                    + "`CEP_cliente`, `celular_cliente`,"
                    + "`num_casa_cliente`, `data_nascimento_cliente`,"
                    + "`bairro_cliente`, `cidade_cliente`,"
                    + "`data_cadastro_cliente`, `nacionalidade_cliente`, "
                    + "`sexualmente_ativo_cliente`, `tipo_sanguineo_cliente`, "
                    + "`estado_civil_cliente`) "
                    
                    + "VALUES (?, ?, ?,"
                    + "(SELECT id_genero FROM genero WHERE nome_genero = ?), '-1', ?, ?, '1', ?, "
                    + "?, ?, '2024-06-12', ?, '1', '3', '1');";

            // Inicia e prepara a conexão com o BD
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, obj.getCpf());
            System.out.println("CPF é: " + obj.getCpf());
            stmt.setString(2, obj.getNome());
            stmt.setString(3, obj.getEmail());
            stmt.setString(4, obj.getNomeSexo());
            System.out.println("NomeSexo é: " + obj.getNomeSexo());
            System.out.println("Sexo é: " + obj.getSexo());
            stmt.setString(5, obj.getCep());
            stmt.setString(6, obj.getCelular());
            stmt.setString(7, obj.getDataNasc());
            stmt.setString(8, obj.getBairro());
            stmt.setString(9, obj.getCidade());
            stmt.setString(10, obj.getNacionalidade());
            
            // Executa a Query
            stmt.execute();
            
            // Fecha a conexão
            stmt.close();
            
            // Aviso que deu certo
            JOptionPane.showMessageDialog(null, "Cliente salvo!");
                
        }catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro ao salvar cliente." + erro);
                }
    }
    
    public void EditarCliente(Cliente obj){
        try {
            //Cria a Query
            String sql = "UPDATE `cliente_cadastro` SET "
                    + "`nome_cliente` = ?, "
                    + "cpf_cnpj_cliente = ?,"
                    + "`email_cliente` = ?, "
                    + "`ID_genero` = (SELECT id_genero FROM genero WHERE nome_genero = ?), "
                    + "`CEP_cliente` = ?, "
                    + "`celular_cliente` = ?, "
                    + "`data_nascimento_cliente` = ?, "
                    + "`bairro_cliente` = ?, "
                    + "`cidade_cliente` = ?, "
                    + "`nacionalidade_cliente` = ? "
                    + "WHERE `ID_cliente` = ?;";

            // Inicia e prepara a conexão com o BD
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, obj.getNome());
            //System.out.println("CPF é: " + obj.getCpf());
            stmt.setString(2, obj.getCpf());
            stmt.setString(3, obj.getEmail());
            stmt.setString(4, obj.getNomeSexo());
            stmt.setString(5, obj.getCep());
            stmt.setString(6, obj.getCelular());
            stmt.setString(7, obj.getDataNasc());
            stmt.setString(8, obj.getBairro());
            stmt.setString(9, obj.getCidade());
            stmt.setString(10, obj.getNacionalidade());
            stmt.setInt(11, obj.getId());
            
            System.out.println("NomeSexo é: " + obj.getNomeSexo());
            System.out.println("Sexo é: " + obj.getSexo());
            
            // Executa a Query
            stmt.execute();
            
            // Fecha a conexão
            stmt.close();
            
            // Aviso que deu certo
            JOptionPane.showMessageDialog(null, "Cliente editado com sucesso!");
                
        }catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "Erro ao editar cliente." + erro);
                }
    }
    
    public Cliente BuscarCliente(String nome){
        try {
            String sql = "SELECT c.ID_cliente,"
                    + " c.nome_cliente,"
                    + " c.email_cliente,"
                    + " c.cpf_cnpj_cliente,"
                    + " g.nome_genero,"
                    + " c.nacionalidade_cliente,"
                    + " c.CEP_cliente,"
                    + " c.celular_cliente,"
                    + " c.data_nascimento_cliente,"
                    + " c.bairro_cliente,"
                    + " c.cidade_cliente"
                    + " FROM cliente_cadastro AS c"
                    + " LEFT JOIN genero AS g"
                    + " ON (g.id_genero = c.ID_genero)"
                    + " WHERE nome_cliente LIKE ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            Cliente obj = new Cliente();
            
            if (rs.next()){
                obj.setId(rs.getInt("c.ID_cliente"));
                obj.setCpf(rs.getString("c.cpf_cnpj_cliente"));
                obj.setNome(rs.getString("c.nome_cliente"));
                obj.setEmail(rs.getString("c.email_cliente"));
                obj.setNomeSexo(rs.getString("g.nome_genero"));
                obj.setCep(rs.getString("c.CEP_cliente"));
                obj.setCelular(rs.getString("c.celular_cliente"));
                obj.setDataNasc(rs.getString("c.data_nascimento_cliente"));
                obj.setBairro(rs.getString("bairro_cliente"));
                obj.setCidade(rs.getString("cidade_cliente"));
                obj.setNacionalidade(rs.getString("nacionalidade_cliente"));
            }
            return obj;
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao mostrar tabela" + e);
        }
        return null;
    }
    public ArrayList<Cliente> Listar(){
        ArrayList<Cliente> lista = new ArrayList<>();
        try {
            String sql = "SELECT c.ID_cliente,"
                    + " c.nome_cliente,"
                    + " c.email_cliente,"
                    + " c.cpf_cnpj_cliente,"
                    + " g.nome_genero,"
                    + " c.nacionalidade_cliente"
                    + " FROM cliente_cadastro AS c"
                    + " LEFT JOIN genero AS g"
                    + " ON (g.id_genero = c.ID_genero)";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while (rs.next()){
                Cliente obj = new Cliente();
                obj.setId(rs.getInt("c.ID_cliente"));                
                obj.setNome(rs.getString("c.nome_cliente"));
                obj.setEmail(rs.getString("c.email_cliente"));
                obj.setCpf(rs.getString("c.cpf_cnpj_cliente"));
                obj.setNomeSexo(rs.getString("g.nome_genero"));
//                obj.setCep(rs.getString("c.CEP_cliente"));
//                obj.setCelular(rs.getString("celular_cliente"));
//                obj.setDataNasc(rs.getString("data_nascimento_cliente"));
//                obj.setBairro(rs.getString("bairro_cliente"));
//                obj.setCidade(rs.getString("cidade_cliente"));
                obj.setNacionalidade(rs.getString("nacionalidade_cliente"));
                lista.add(obj);
            }
            return lista;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "erro ao listar"+e);
        }
        return null;
    }
    
    public ArrayList<Cliente> Filtrar(String nome){
        ArrayList<Cliente> lista = new ArrayList<>();
        try {
            String sql = "SELECT c.ID_cliente,"
                    + " c.nome_cliente,"
                    + " c.email_cliente,"
                    + " c.cpf_cnpj_cliente,"
                    + " g.nome_genero,"
                    + " c.nacionalidade_cliente"
                    + " FROM cliente_cadastro AS c"
                    + " LEFT JOIN genero AS g"
                    + " ON (g.id_genero = c.ID_genero)"
                    + " WHERE c.nome_cliente LIKE ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()){
                Cliente obj = new Cliente();
                obj.setId(rs.getInt("c.ID_cliente"));
                obj.setNome(rs.getString("c.nome_cliente"));
                obj.setEmail(rs.getString("c.email_cliente"));
                obj.setCpf(rs.getString("c.cpf_cnpj_cliente"));
                obj.setNomeSexo(rs.getString("g.nome_genero"));
                obj.setNacionalidade(rs.getString("nacionalidade_cliente"));
                lista.add(obj);
            }
            return lista;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "erro ao listar"+e);
        }
        return null;
    }
    
    public void Excluir(Cliente obj){
        try {
            String sql = "DELETE FROM cliente_cadastro WHERE ID_cliente = ?";
            
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setInt(1, obj.getId());
            
            stmt.execute();
            stmt.close();
            
            JOptionPane.showMessageDialog(null, "Excluído com sucesso");
            
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Falha ao excluir"+e);

        }

    }
}


