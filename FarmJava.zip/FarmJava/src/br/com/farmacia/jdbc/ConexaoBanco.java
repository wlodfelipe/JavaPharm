/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.farmacia.jdbc;

/**
 *
 * @author felipewlod
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexaoBanco {
    final private String url = "jdbc:mysql://200.195.171.122/grupo11_wlodfelipe";
    final private String usuario = "grupo11";
    final private String senha = "9agmsegriCatwXLH";
    
    public Connection conectardb(){
        try{
        return DriverManager.getConnection(url, usuario, senha);
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Erro ao conectar ao Banco de Dados"+e);
        }
        return null;
    }
    
}
